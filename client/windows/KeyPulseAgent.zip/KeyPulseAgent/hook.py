from __future__ import annotations

import ctypes
import threading
import time
from ctypes import wintypes
from typing import Callable

from keymap import resolve_key

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

WH_KEYBOARD_LL = 13
WM_KEYDOWN = 0x0100
WM_SYSKEYDOWN = 0x0104
WM_QUIT = 0x0012

LowLevelKeyboardProc = ctypes.WINFUNCTYPE(
    wintypes.LPARAM,
    ctypes.c_int,
    wintypes.WPARAM,
    wintypes.LPARAM,
)


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class KeyboardHook:
    def __init__(self, on_key_down: Callable[[str, int], None]) -> None:
        self._on_key_down = on_key_down
        self._hook_id = None
        self._proc = LowLevelKeyboardProc(self._callback)
        self._thread: threading.Thread | None = None
        self._thread_id: int | None = None
        self._ready = threading.Event()
        self._failed = threading.Event()
        self._failure_message = ""

    @property
    def failure_message(self) -> str:
        return self._failure_message

    def _callback(self, n_code: int, w_param: wintypes.WPARAM, l_param: wintypes.LPARAM) -> wintypes.LPARAM:
        if n_code >= 0 and w_param in (WM_KEYDOWN, WM_SYSKEYDOWN):
            event = ctypes.cast(l_param, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
            key = resolve_key(event.vkCode, event.flags)
            if key:
                timestamp_ms = int(time.time() * 1000)
                self._on_key_down(key, timestamp_ms)
        return user32.CallNextHookEx(None, n_code, w_param, l_param)

    def _thread_main(self) -> None:
        self._thread_id = kernel32.GetCurrentThreadId()
        self._hook_id = user32.SetWindowsHookExW(
            WH_KEYBOARD_LL,
            self._proc,
            None,
            0,
        )
        if not self._hook_id:
            self._failure_message = "键盘钩子安装失败，请确认 KeyPulse 未被安全软件拦截。"
            self._failed.set()
            return

        self._ready.set()
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))

        if self._hook_id:
            user32.UnhookWindowsHookEx(self._hook_id)
            self._hook_id = None

    def start(self, timeout: float = 3.0) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._ready.clear()
        self._failed.clear()
        self._thread = threading.Thread(target=self._thread_main, name="KeyPulseHook", daemon=True)
        self._thread.start()
        if self._failed.wait(timeout):
            raise RuntimeError(self._failure_message or "键盘钩子启动失败。")
        if not self._ready.wait(timeout):
            raise RuntimeError("键盘钩子启动超时。")

    def stop(self) -> None:
        if self._thread_id:
            user32.PostThreadMessageW(self._thread_id, WM_QUIT, 0, 0)
        if self._thread:
            self._thread.join(timeout=2.0)
        self._thread = None
        self._thread_id = None
        self._hook_id = None
