#Requires -Version 5.1
$ErrorActionPreference = "Stop"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Release = Join-Path (Split-Path -Parent $Root) "release"
$Dist = Join-Path $Root "dist"
$Build = Join-Path $Root "build"

Set-Location $Root

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "未找到 python，请先安装 Python 3.10+ 并加入 PATH。"
}

python -m pip install --upgrade pip
python -m pip install -r requirements.txt

if (Test-Path $Release) { Remove-Item $Release -Recurse -Force }
if (Test-Path $Dist) { Remove-Item $Dist -Recurse -Force }
if (Test-Path $Build) { Remove-Item $Build -Recurse -Force }

python -m PyInstaller `
    --noconfirm `
    --clean `
    --onefile `
    --windowed `
    --name KeyPulse `
    --distpath $Release `
    --workpath $Build `
    --specpath $Root `
    main.py

Write-Host ""
Write-Host "构建完成：$Release\KeyPulse.exe"
Write-Host "可将 KeyPulse.exe 复制到任意目录运行，或固定到开始菜单。"
